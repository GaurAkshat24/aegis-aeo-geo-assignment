# AEGIS — Answer Engine & Generative Intelligence Suite

## Overview
AEGIS is a Python/FastAPI content intelligence platform for AEO (Answer Engine Optimization)
and GEO (Generative Engine Optimization). It scores content across three NLP checks and
provides query fan-out gap analysis via LLM + sentence-transformer embeddings.

Built as a take-home assignment for an AI Engineer role.

## Project Structure
```
app/
├── main.py                       # FastAPI entry point
├── api/
│   ├── aeo.py                    # POST /api/aeo/analyze
│   └── fanout.py                 # POST /api/fanout/generate
├── models/
│   └── schemas.py                # All Pydantic request/response models
└── services/
    ├── content_parser.py         # HTML fetch (httpx) + boilerplate stripping
    ├── fanout_engine.py          # LLM prompt, retry logic, JSON validation
    ├── gap_analyzer.py           # sentence-transformers embeddings + cosine sim
    └── aeo_checks/
        ├── base.py               # BaseCheck abstract class
        ├── direct_answer.py      # Check A: spaCy dep-parse + word count + hedges
        ├── htag_hierarchy.py     # Check B: BeautifulSoup H-tag rules
        └── readability.py        # Check C: textstat FK grade + complex sentences
tests/
├── test_direct_answer.py
├── test_htag_hierarchy.py
├── test_readability.py
└── test_fanout_parsing.py        # LLM JSON parsing/validation (mocked LLM)
```

## Technologies
- **Language:** Python 3.11
- **Framework:** FastAPI + Uvicorn
- **NLP:** spaCy (en_core_web_sm), textstat
- **Embeddings:** sentence-transformers (all-MiniLM-L6-v2)
- **LLMs:** google-genai (Gemini 1.5 Flash, primary), OpenAI GPT-4o-mini (fallback)
- **HTML parsing:** BeautifulSoup4 + httpx
- **Testing:** pytest (35 tests, all passing)

## Environment Variables
- `GEMINI_API_KEY` — Required for `/api/fanout/generate` (Gemini 1.5 Flash)
- `OPENAI_API_KEY` — Optional fallback for fan-out (GPT-4o-mini)
- Feature 1 (AEO scoring) requires no API keys.

## API Endpoints
- `GET /` — Health check
- `POST /api/aeo/analyze` — AEO content scoring (0–100 score + 3 check results)
- `POST /api/fanout/generate` — LLM query fan-out + optional gap analysis
- `GET /docs` — Swagger UI (auto-generated)

## Running
```bash
uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
pytest tests/ -v
```

## Key Architecture Decisions
- **Modular NLP pipeline:** each check is an independent `BaseCheck` subclass — easy to
  add new checks without modifying existing code
- **Defensive LLM handling:** 3 retries, escalating temperature, JSON extraction +
  Pydantic-equivalent validation, explicit error codes on failure
- **all-MiniLM-L6-v2 chosen** for 5× speed advantage over mpnet with ~1% accuracy loss
- **Explicit cosine similarity** normalisation to avoid raw dot-product bug
- **Non-fatal gap analysis:** if embeddings fail, sub-queries are returned without
  coverage data rather than failing the entire request

## Deliverables Checklist
- [x] `POST /api/aeo/analyze` — fully implemented
- [x] `POST /api/fanout/generate` — fully implemented
- [x] 35 tests (all passing)
- [x] `README.md` — engineering decisions, env vars, run commands
- [x] `PROMPT_LOG.md` — 3-draft prompt iteration log
- [x] `ASSIGNMENT_README.md` — original assignment brief preserved
